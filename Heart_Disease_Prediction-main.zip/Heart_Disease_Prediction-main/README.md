Heart disease is one of the most common diseases in the world. The objective of this study is to aid the diagnosis of heart disease .
